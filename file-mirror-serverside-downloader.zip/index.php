<?php
// Enable full error reporting at the very top
error_reporting(E_ALL);
ini_set('display_errors', 0); // Don't display errors to the browser, but they will be logged
ini_set('log_errors', 1);

// --- CONFIGURATION ---
$passkey = 'onelife'; // !!! IMPORTANT: Change this to your own secret passkey !!!
$user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36';
$download_directory = __DIR__ . '/files'; // Use absolute path for reliability
$self_script_url = $_SERVER['PHP_SELF'];
$downloadable_extensions = ['zip', 'rar', '7z', 'tar', 'gz', 'iso', 'mkv', 'mp4', 'avi', 'mov', 'exe', 'dmg', 'pkg'];

// --- AUTHENTICATION & SESSION ---
session_start();

// --- ROUTER & LOGIC EXECUTION ---
// All logic must execute BEFORE any HTML is sent.

// Logout Action
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_unset();
    session_destroy();
    header('Location: ' . htmlspecialchars($self_script_url));
    exit;
}

// Login Attempt
$login_error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['passkey'])) {
    if ($_POST['passkey'] === $passkey) {
        $_SESSION['is_authenticated'] = true;
        header('Location: ' . htmlspecialchars($self_script_url));
        exit;
    } else {
        $login_error = "Invalid passkey. Please try again.";
    }
}

// Check if user is authenticated
function is_authenticated() {
    return isset($_SESSION['is_authenticated']) && $_SESSION['is_authenticated'] === true;
}

// --- ACTION HANDLERS ---
function handle_get_log() {
    global $download_directory;
    header('Content-Type: application/json');
    $log_file_path = '';
    $response = ['logContent' => 'Waiting for status...', 'isFinished' => false, 'error' => ''];

    if (!empty($_GET['log_file'])) {
        $log_filename = basename($_GET['log_file']);
        if (strpos($log_filename, 'download_') === 0 && substr($log_filename, -4) === '.log') {
            $log_file_path = $download_directory . '/' . $log_filename;
        }
    }

    if (empty($log_file_path) || !file_exists($log_file_path)) {
        $response['error'] = 'Log file not found or invalid.';
        $response['isFinished'] = true;
    } else {
        $content = file_get_contents($log_file_path);
        $lines = explode("\n", trim($content));
        $last_meaningful_line = '';
        for ($i = count($lines) - 1; $i >= 0; $i--) {
            $line = trim($lines[$i]);
            if (empty($line)) continue;
            if (strpos($line, '%') !== false) {
                $last_cr_pos = strrpos($line, "\r");
                $last_meaningful_line = ($last_cr_pos !== false) ? trim(substr($line, $last_cr_pos + 1)) : $line;
                break;
            }
            if ($last_meaningful_line === '') $last_meaningful_line = $line;
        }
        $response['logContent'] = $last_meaningful_line ?: 'Connecting...';
        if (strpos($content, ' saved [') !== false || strpos($content, '100%') !== false) {
            $response['isFinished'] = true;
            $meta_file_path = $log_file_path . '.meta';
            @unlink($log_file_path);
            @unlink($meta_file_path);
        }
    }
    
    echo json_encode($response);
    exit;
}

function handle_start_download() {
    global $self_script_url;
    if (empty($_GET['url'])) die("Download URL is missing.");
    $url = $_GET['url'];
    $log_file_to_poll = start_wget_download($url);
    if ($log_file_to_poll) {
        header('Location: ' . $self_script_url . '?log_file=' . $log_file_to_poll);
    } else {
        header('Location: ' . $self_script_url . '?error=download_failed');
    }
    exit;
}

function handle_proxy_browse($url) {
    global $user_agent, $self_script_url, $downloadable_extensions;

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    $html = curl_exec($ch);
    $content_type = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    $effective_url = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    curl_close($ch);

    if (strpos($content_type, 'text/html') !== false && $html) {
        $doc = new DOMDocument();
        @$doc->loadHTML($html, LIBXML_NOERROR | LIBXML_NOWARNING);

        $head = $doc->getElementsByTagName('head')->item(0);
        if ($head) {
            $base = $doc->createElement('base');
            $base->setAttribute('href', $effective_url);
            if ($head->firstChild) $head->insertBefore($base, $head->firstChild);
            else $head->appendChild($base);
        }

        $tags = $doc->getElementsByTagName('*');
        foreach ($tags as $tag) {
            $attr = '';
            if ($tag->hasAttribute('href')) $attr = 'href';
            if ($tag->hasAttribute('src')) $attr = 'src';
            if (empty($attr)) continue;

            $original_link = $tag->getAttribute($attr);
            if (empty($original_link) || strpos(trim($original_link), 'javascript:') === 0) continue;

            $absolute_link = resolve_url($effective_url, $original_link);
            $path_info = pathinfo(parse_url($absolute_link, PHP_URL_PATH));
            $extension = isset($path_info['extension']) ? strtolower($path_info['extension']) : '';

            if ($tag->nodeName == 'a' && in_array($extension, $downloadable_extensions)) {
                $tag->setAttribute($attr, $self_script_url . '?action=start_download&url=' . urlencode($absolute_link));
                $tag->setAttribute('target', '_blank');
                $tag->setAttribute('style', 'font-weight:bold; color:red; border:1px solid red; padding:2px; border-radius:3px;');
            } else if ($attr === 'href') {
                $tag->setAttribute($attr, $self_script_url . '?browse_url=' . urlencode($absolute_link));
            } else {
                $tag->setAttribute($attr, $absolute_link);
            }
        }
        echo $doc->saveHTML();
    } else {
        header("Content-Type: " . ($content_type ?: 'text/plain'));
        echo $html;
    }
    exit;
}

function start_wget_download($url) {
    global $download_directory, $user_agent;
    if (filter_var($url, FILTER_VALIDATE_URL) === FALSE) return false;
    
    if (!is_dir($download_directory)) {
        if (!mkdir($download_directory, 0755, true)) return false;
    }

    $path = parse_url($url, PHP_URL_PATH);
    $filename = basename($path) ?: 'download_' . time();
    $log_filename = 'download_' . md5($url) . '.log';
    
    $output_path = $download_directory . '/' . $filename;
    $log_path = $download_directory . '/' . $log_filename;
    $meta_path = $log_path . '.meta';

    file_put_contents($meta_path, $url);

    $escaped_url = escapeshellarg($url);
    $escaped_output_path = escapeshellarg($output_path);
    $escaped_log_path = escapeshellarg($log_path);
    $escaped_user_agent = escapeshellarg($user_agent);

    $command = "nohup wget --progress=bar:force -c --tries=0 --timeout=60 --read-timeout=600 --user-agent={$escaped_user_agent} -o {$escaped_log_path} -O {$escaped_output_path} {$escaped_url} > /dev/null 2>&1 &";
    shell_exec($command);
    return $log_filename;
}

function resolve_url($base, $relative) {
    if (empty($relative) || strpos($relative, 'data:') === 0) return $relative;
    if (parse_url($relative, PHP_URL_SCHEME) != '') return $relative;
    $base_parts = parse_url($base);
    if ($relative[0] == '#') return $base;
    if ($relative[0] == '?') return ($base_parts['path'] ?? '/') . $relative;
    if (substr($relative, 0, 2) == '//') return ($base_parts['scheme'] ?? 'http') . ':' . $relative;
    $path = $base_parts['path'] ?? '/';
    if ($relative[0] == '/') $path = $relative;
    else $path = dirname($path) . '/' . $relative;
    $parts = [];
    foreach (explode('/', $path) as $part) {
        if ($part === '.' || $part === '') continue;
        if ($part === '..') array_pop($parts);
        else $parts[] = $part;
    }
    $abs_path = '/' . implode('/', $parts);
    return ($base_parts['scheme'] ?? 'http') . '://' . ($base_parts['host'] ?? '') . $abs_path;
}

function list_files($dir) {
    if (!is_dir($dir)) return '<p class="text-gray-500">The "'.htmlspecialchars(basename($dir)).'" directory doesn\'t exist yet.</p>';
    
    // Corrected regex to filter out .log and .log.meta files
    $files = array_filter(scandir($dir), fn($file) => !in_array($file, ['.', '..']) && !preg_match('/\.log(\.meta)?$/i', $file));
    
    if (empty($files)) return '<p class="text-gray-500">No files in the "'.htmlspecialchars(basename($dir)).'" directory yet.</p>';
    
    $html = '<ul class="list-disc list-inside space-y-2">';
    foreach ($files as $file) $html .= '<li>' . htmlspecialchars($file) . '</li>';
    $html .= '</ul>';
    return $html;
}

function list_ongoing_downloads($dir) {
    global $self_script_url;
    if (!is_dir($dir)) return '';

    $log_files = glob($dir . '/download_*.log');
    if (empty($log_files)) return '';

    $html = '<div class="bg-white shadow-lg rounded-xl p-8 mt-6">';
    $html .= '<h2 class="text-xl font-semibold text-gray-800 mb-4">Ongoing Downloads</h2>';
    $html .= '<div class="space-y-3">';
    foreach ($log_files as $log_file) {
        $filename = basename($log_file);
        $html .= '<div class="flex items-center justify-between bg-gray-50 p-3 rounded-lg">';
        $html .= '<span class="text-gray-700 font-mono text-sm">' . htmlspecialchars($filename) . '</span>';
        $html .= '<a href="' . htmlspecialchars($self_script_url) . '?log_file=' . htmlspecialchars($filename) . '" class="bg-green-500 hover:bg-green-600 text-white text-xs font-bold py-1 px-3 rounded-full transition-colors">Check Status</a>';
        $html .= '</div>';
    }
    $html .= '</div></div>';
    return $html;
}

// --- GATEKEEPER ---
// If not authenticated, show the login page and stop.
if (!is_authenticated()) {
    // The login form HTML
    $login_page_html = <<<HTML
    <!DOCTYPE html>
    <html lang="en" class="h-full bg-gray-100">
    <head>
        <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Authentication Required</title>
        <script src="https://cdn.tailwindcss.com"></script><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
        <style>body { font-family: 'Inter', sans-serif; }</style>
    </head>
    <body class="h-full flex items-center justify-center p-4">
        <div class="w-full max-w-md mx-auto"><div class="bg-white shadow-lg rounded-xl p-8">
            <div class="mb-6 text-center"><h1 class="text-2xl font-bold text-gray-800">Authentication Required</h1><p class="text-gray-500 mt-1">Please enter the passkey to continue.</p></div>
            %s
            <form method="POST" action="%s" class="space-y-4">
                <div><label for="passkey" class="block text-sm font-medium text-gray-700 mb-1">Passkey</label>
                <input type="password" id="passkey" name="passkey" required autofocus class="block w-full px-4 py-2 text-gray-900 border border-gray-300 rounded-lg bg-gray-50 focus:ring-indigo-500 focus:border-indigo-500 transition"></div>
                <button type="submit" class="w-full text-white bg-indigo-600 hover:bg-indigo-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center">Unlock</button>
            </form>
        </div></div>
    </body></html>
HTML;
    $error_html = $login_error ? '<div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded-lg" role="alert"><p>' . $login_error . '</p></div>' : '';
    printf($login_page_html, $error_html, htmlspecialchars($self_script_url));
    exit;
}

// If we reach here, the user is authenticated. We can run ajax actions or prepare the main page.
if (isset($_GET['action']) && $_GET['action'] === 'get_log') handle_get_log();
if (isset($_GET['browse_url']) && !empty($_GET['browse_url'])) handle_proxy_browse($_GET['browse_url']);
if (isset($_GET['action']) && $_GET['action'] === 'start_download') handle_start_download();

// --- MAIN PAGE PREPARATION (Only runs if authenticated) ---
$message = '';
$message_type = '';
$log_file_to_poll = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['url'])) {
    $log_file_to_poll = start_wget_download($_POST['url']);
    if ($log_file_to_poll) {
        $message = 'Success! Download started. See live status below.';
        $message_type = 'success';
    } else {
        $message = 'Error: Failed to start download. Check URL/permissions.';
        $message_type = 'error';
    }
}
if (isset($_GET['log_file'])) {
    $log_file_to_poll = basename($_GET['log_file']);
    $message = 'Checking download status. See live status below.';
    $message_type = 'success';
}
if (isset($_GET['error'])) {
    $message = 'An error occurred during download initiation.';
    $message_type = 'error';
}

// Now we can safely output the main application HTML
?>
<!DOCTYPE html>
<html lang="en" class="h-full bg-gray-50">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Server Downloader & Browser</title>
    <script src="https://cdn.tailwindcss.com"></script><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        .message { padding: 1rem; margin-bottom: 1.5rem; border-radius: 0.5rem; border-width: 1px; }
        .message.success { background-color: #f0fdf4; border-color: #bbf7d0; color: #166534; }
        .message.error { background-color: #fef2f2; border-color: #fecaca; color: #991b1b; }
        #log-output-container { font-family: monospace; font-size: 0.875rem; }
        .tab-button { padding: 0.5rem 1rem; border-radius: 0.5rem; cursor: pointer; transition: all 0.2s; }
        .tab-button.active { background-color: #4f46e5; color: white; }
        .tab-button:not(.active) { background-color: #e5e7eb; color: #374151; }
        .tab-content { display: none; }
    </style>
</head>
<body class="h-full bg-gray-100 p-4">
    <div class="w-full max-w-4xl mx-auto">
        <div class="bg-white shadow-lg rounded-xl p-8 relative">
            <a href="?action=logout" class="absolute top-4 right-4 text-sm text-gray-500 hover:text-indigo-600">Logout</a>
            <div class="mb-6 text-center"><h1 class="text-2xl font-bold text-gray-800">Server Downloader & Browser</h1></div>
            
            <div class="flex justify-center space-x-4 mb-6 border-b pb-4">
                <button id="tab-downloader" class="tab-button active">Direct Downloader</button>
                <button id="tab-browser" class="tab-button">Proxy Browser</button>
            </div>

            <div id="log-container" class="hidden mb-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-2">Live Status</h3>
                <div id="log-status" class="message success"><?php echo $message; ?></div>
                <div id="log-output-container" class="p-4 bg-gray-900 text-white rounded-lg overflow-x-auto">
                    <code id="log-output">Waiting for status...</code>
                </div>
            </div>
            
            <?php if ($message && !$log_file_to_poll): ?>
                <div class="message <?php echo $message_type; ?>" role="alert"><?php echo $message; ?></div>
            <?php endif; ?>

            <div id="content-downloader" class="tab-content">
                <p class="text-gray-500 mt-1 text-center mb-4">Paste a direct download link to fetch a file to the server.</p>
                <form action="<?php echo htmlspecialchars($self_script_url); ?>" method="POST" class="space-y-4">
                    <div><label for="url" class="block text-sm font-medium text-gray-700 mb-1">File URL</label>
                    <input type="url" id="url" name="url" required class="block w-full px-4 py-2 border rounded-lg" placeholder="https://example.com/file.zip"></div>
                    <button type="submit" class="w-full text-white bg-blue-600 hover:bg-blue-700 font-medium rounded-lg px-5 py-2.5">Download File</button>
                </form>
            </div>

            <div id="content-browser" class="tab-content">
                 <p class="text-gray-500 mt-1 text-center mb-4">Browse a website from the server.</p>
                <form action="<?php echo htmlspecialchars($self_script_url); ?>" method="GET" class="space-y-4">
                    <div><label for="browse_url" class="block text-sm font-medium text-gray-700 mb-1">Website URL</label>
                    <input type="url" id="browse_url" name="browse_url" required class="block w-full px-4 py-2 border rounded-lg" placeholder="https://example.com"></div>
                    <button type="submit" class="w-full text-white bg-indigo-600 hover:bg-indigo-700 font-medium rounded-lg px-5 py-2.5">Browse from Server</button>
                </form>
            </div>
        </div>

        <?php echo list_ongoing_downloads($download_directory); ?>

        <div class="bg-white shadow-lg rounded-xl p-8 mt-6">
            <h2 class="text-xl font-semibold text-gray-800 mb-4">Files in '<?php echo htmlspecialchars(basename($download_directory)); ?>' Directory</h2>
            <div class="p-4 bg-gray-50 rounded-lg border">
                <?php echo list_files($download_directory); ?>
            </div>
        </div>
    </div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const tabDownloaderBtn = document.getElementById('tab-downloader');
    const tabBrowserBtn = document.getElementById('tab-browser');
    const contentDownloader = document.getElementById('content-downloader');
    const contentBrowser = document.getElementById('content-browser');
    
    contentDownloader.style.display = 'block';

    tabDownloaderBtn.addEventListener('click', () => {
        tabDownloaderBtn.classList.add('active');
        tabBrowserBtn.classList.remove('active');
        contentDownloader.style.display = 'block';
        contentBrowser.style.display = 'none';
    });

    tabBrowserBtn.addEventListener('click', () => {
        tabBrowserBtn.classList.add('active');
        tabDownloaderBtn.classList.remove('active');
        contentBrowser.style.display = 'block';
        contentDownloader.style.display = 'none';
    });
    
    const logFile = '<?php echo $log_file_to_poll; ?>';
    
    if (logFile) {
        const logContainer = document.getElementById('log-container');
        const logOutput = document.getElementById('log-output');
        const logStatus = document.getElementById('log-status');
        logContainer.classList.remove('hidden');
        tabDownloaderBtn.click();

        const pollInterval = setInterval(() => {
            fetch(`?action=get_log&log_file=${logFile}`)
                .then(response => response.json())
                .then(data => {
                    if (data.error) {
                        logOutput.textContent = `Error: ${data.error}`;
                        clearInterval(pollInterval);
                        return;
                    }
                    logOutput.textContent = data.logContent;
                    if (data.isFinished) {
                        logStatus.innerHTML = '<strong>Download complete!</strong> Refreshing page...';
                        logStatus.classList.replace('success', 'message');
                        logStatus.style.backgroundColor = '#e0f2fe';
                        clearInterval(pollInterval);
                        setTimeout(() => location.href = '<?php echo $self_script_url; ?>', 2500);
                    }
                })
                .catch(error => {
                    logOutput.textContent = `Polling error: ${error}. Please refresh page.`;
                    clearInterval(pollInterval);
                });
        }, 2000);
    }
});
</script>
</body>
</html>
