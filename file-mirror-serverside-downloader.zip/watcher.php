<?php
// --- Watcher Script ---
// This script is meant to be invoked via a cron-triggered wget call or direct URL access.

// Enable full error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// --- CONFIGURATION (must match your main script) ---
$download_directory = __DIR__ . '/files';
$user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36';

echo "--- Aggressive Watcher script started at " . date('Y-m-d H:i:s') . " ---\n";

// --- FUNCTIONS ---
function start_wget_download_from_watcher($url) {
    global $download_directory, $user_agent;
    if (!filter_var($url, FILTER_VALIDATE_URL)) {
        return false;
    }
    
    if (!is_dir($download_directory)) {
        if (!mkdir($download_directory, 0755, true)) {
            echo "  -> FATAL ERROR: Could not create download directory at {$download_directory}\n";
            return false;
        }
    }

    $path = parse_url($url, PHP_URL_PATH);
    $filename = basename($path) ?: 'download_' . time();
    $log_filename = 'download_' . md5($url) . '.log';
    
    $output_path = $download_directory . '/' . $filename;
    $log_path    = $download_directory . '/' . $log_filename;

    $escaped_url         = escapeshellarg($url);
    $escaped_output_path = escapeshellarg($output_path);
    $escaped_log_path    = escapeshellarg($log_path);
    $escaped_user_agent  = escapeshellarg($user_agent);

    $command = "nohup wget --progress=bar:force -c --tries=0 --timeout=60 --read-timeout=600 \
        --user-agent={$escaped_user_agent} -o {$escaped_log_path} -O {$escaped_output_path} {$escaped_url} > /dev/null 2>&1 &";
    shell_exec($command);
    return $log_filename;
}

// --- MAIN WATCHER LOGIC ---
$log_files = glob($download_directory . '/download_*.log');

if ($log_files === false) {
    echo "ERROR: Failed to read from download directory: {$download_directory}. Check permissions.\n";
    exit;
}

if (empty($log_files)) {
    echo "No active downloads found to monitor.\n";
    exit;
}

echo "Found " . count($log_files) . " log file(s) to check.\n";

foreach ($log_files as $log_file) {
    echo "-> Force-checking: " . basename($log_file) . "\n";
    $meta_file = $log_file . '.meta';
    
    if (file_exists($meta_file)) {
        $url = trim(file_get_contents($meta_file));
        if (filter_var($url, FILTER_VALIDATE_URL)) {
            echo "  - Found URL. Issuing continue/restart command.\n";
            start_wget_download_from_watcher($url);
        } else {
            echo "  - ERROR: Invalid URL in meta for " . basename($log_file) . ". Skipping.\n";
        }
    } else {
        echo "  - ERROR: .meta file not found for " . basename($log_file) . ". Skipping.\n";
    }
}

echo "--- Watcher script finished. ---\n";

// Cron command (no key required):
// wget -q -O - "https://parvrish.com/donloder/watcher.php" > /dev/null 2>&1
?>
